HAPPY BIRTHDAY WEBSITE — READY TO PUBLISH

Included:
- index.html — birthday website
- girl.jpeg — the photo you supplied, added to the photo frame

To publish it so it works on other devices:
1. Keep index.html and girl.jpeg together.
2. Upload the ZIP to a static website host such as Netlify Drop: https://app.netlify.com/drop
3. Copy the public https:// link created by the host.
4. Use that public link for your QR code. A file:/// link only works on your own computer.

If you update the site later, upload both files together again.
